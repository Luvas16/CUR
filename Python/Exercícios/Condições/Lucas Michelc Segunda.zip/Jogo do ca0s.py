#importações
import random;
import time;
import os;

#variáveis
respostamenu = int(0);
selecaodificuldade = int(0);
chance = int(0);
dica = int(0);
resposta1 = int(0)

print('Pressione alguma opção para se conectar ao anfitrião')
print('1 = Conectar')
print('0 = Sair')
respostamenu = int(input('digite sua escolha: '));

if (respostamenu == 0):
    print('QUAL É! VOLTA AQUI E JOGA A M3RD4 DO MEU JOGO, VOOOOOOLTAAAAAAAAAAAA');
    while (True):
        print('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa')
        break;

if (respostamenu == 1):
    print ('escolha o quão difícil você quer que o nosso joguinho seja');
    print ('1 = Anarquia: \n para os verdadeiros anárquicos que desejam um grande desafio contra o ca0s');
    print ('2 = Desordem: \n para aqueles que querem um desafio pequeno, também conhecidos como covardes hahahahahahahahahahaha');
    print ('3 = Mal controlado: \n Para aqueles que querem um passeio no parque, os Burros acomodados kskksksksksks');

    selecaodificuldade = int(input('digite sua escolha: '));

    if (selecaodificuldade == 1):
        dica = int(1);
        chance = random.randint(1, 2);
    if (selecaodificuldade == 2):
        dica = int(2);
        chance = random.randint(2, 3);
    if (selecaodificuldade == 3):
        dica = int(3);
        chance = int(3);

    print(f'Vamos JoGar um JoGO, Você terá que me responder o seguinte, eu lhe farei uma pergunta e te darei {dica} dicas e 5 opções,\n descubra a resposta corrreta e se torne um milio... show errado, calma, NÃO, O JOGO É ESSE MESMO');
    print(f'Você tem.... {chance} chances, Boooa Sorte.')
    time.sleep(5)
    print ('Quem é mais louco que todos vocês?')
    print('1 - Monarck')
    print('2 - Monarca')
    print('3 - EUUUUUUU')
    print('4 - dica')
    resposta1 = int(input('digite sua escolha: '));

    if (resposta1 == 4):
        dica = dica - 1
        dica1 = print('Quem que é monarca cara, você conhece? eu não')
        resposta1 = int(input('digite sua escolha: '));
    
    if (resposta1 == 1 or resposta1 == 3):
        print('NÃO É BOM PODER GANHAR UMA VEZ?')

    if (resposta1 == 2):
        print('teClado fEio, Teclado FeIo, TEcLadO fEio')
        chance = chance - 1
        print(f'{chance} tentativas restantes')

        if (dica == 0):
            print('Ops, parece que o conhecimento não está aqui para te ajudar, tendo novamente mais tarde \n :D hahhahhahahhahaa')
            print(f'{dica} dicas restantes')
            resposta2 = int(input('digite sua escolha: '));

        if (chance == 0):
            print('O caos é inevitável hahahahhhhahahahahahahahahaha')
            exit()
    
    print ('Qual a maior fraquesa da humanidade? (dentre essas opções)')
    print('1 - A morte')
    print('2 - O sentimento')
    print('3 - O conhecimento')
    print('4 - dica')
    resposta2 = int(input('digite sua escolha: '));

    if (resposta2 == 4):
        dica = dica - 1
        dica2 = print('dá até sono...')
        resposta2 = int(input('digite sua escolha: '));
    
    if (resposta2 == 1 or resposta2 == 3):
        print('CONTINUA! CONTINUA! CONTINUA KLSSKSKSKSKKS');

    if (resposta2 == 2):
        print('Burro Burro BuRRo BUUro buurrroooo')
        chance = chance - 1
        print(f'{chance} tentativas restantes')

        if (dica == 0):
            print('Ops, parece que o conhecimento não está aqui para te ajudar, tendo novamente mais tarde \n :D hahhahhahahhahaa')
            print(f'{dica} dicas restantes')
            resposta2 = int(input('digite sua escolha: '));

        if (chance == 0):
            print('O caos é inevitável hahahahhhhahahahahahahahahaha')
            exit()

    print ('O que é ca0s?')
    print('1 - A perfeição')
    print('2 - Um emaranhado de sentimentos inexplicáveis')
    print('3 - EUUUUUUU')
    print('4 - dica')
    resposta3 = int(input('digite sua escolha: '));

    if (resposta3 == 4):
        dica = dica - 1
        dica3 = print('Espelho, espelho meu, existe alguêm mais perfeito do que eu? NÃO RESPONDE')
        resposta3 = int(input('digite sua escolha: '));
    
    if (resposta3 == 1 or resposta3 == 3):
        print('SIM, EUUUUUUUUUUU');

    if (resposta3 == 2):
        print('nheeee, não... só não')
        chance = chance - 1
        print(f'{chance} tentativas restantes')

        if (dica == 0):
            print('Ops, parece que o conhecimento não está aqui para te ajudar, tendo novamente mais tarde \n :D hahhahhahahhahaa')
            print(f'{dica} dicas restantes')
            resposta2 = int(input('digite sua escolha: '));

        if (chance == 0):
            print('O caos é inevitável hahahahhhhahahahahahahahahaha')
            exit()

        if (selecaodificuldade == 3):
            print('BRAVO! BRAVO! JÁ POSSO TE CONTRATAR PARA SER O PRÓXIMO DIRETOR! \n SE VOCÊ APRENDESSE A JOGAR DIREITO')

        if (selecaodificuldade == 1 and chance == 3):
            print('BRAVO! BRAVO! JÁ POSSO TE CONTRATAR COMO MEMBRO DA MINHA PRODUÇÃO, \n OU MELHOR AINDA, SER O PRÓXIMO DIRETOR! VOCÊ VAI FAZER UM SHOOOOWWWWWWW')

    print('foi um bom jogo, VAMOS JOGAR DE NOVO?')
    
    
#while (True): perguntadavez = random.randint ( pergunta1, pergunta2, pergunta3 ) print (f'{perguntadavez}') break;